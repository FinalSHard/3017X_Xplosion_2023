/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\carston.ransom                                   */
/*    Created:      Thu Sep 07 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// LeftIntake           motor         2               
// RightIntake          motor         3               
// Drivetrain           drivetrain    1, 4, 9, 10     
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  Drivetrain.setDriveVelocity(200,rpm);
  LeftIntake.setVelocity(200,rpm);
  RightIntake.setVelocity(200,rpm);

  while(Controller1.ButtonL1.pressing()){
    LeftIntake.spin(reverse);
    RightIntake.spin(forward);
  }
  while(Controller1.ButtonL2.pressing()){
    LeftIntake.spin(reverse);
    RightIntake.spin(forward);
  }
}
